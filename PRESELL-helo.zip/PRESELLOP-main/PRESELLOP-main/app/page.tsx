"use client"

import PreSellPage from "../presell-page"

export default function SyntheticV0PageForDeployment() {
  return <PreSellPage />
}